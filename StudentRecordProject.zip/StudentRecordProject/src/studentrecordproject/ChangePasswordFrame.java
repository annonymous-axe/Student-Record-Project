package studentrecordproject;

import javax.swing.JOptionPane;

public class ChangePasswordFrame extends javax.swing.JFrame {

    public ChangePasswordFrame() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        username_txt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        old_password = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        new_password = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        conf_password = new javax.swing.JPasswordField();
        chenge_pass_btn = new javax.swing.JButton();
        chenge_pass_btn1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Change Password");
        setExtendedState(1);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jLabel1.setText("Username");

        username_txt.setFont(new java.awt.Font("Cambria", 1, 25)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jLabel2.setText("Old Password");

        old_password.setFont(new java.awt.Font("Cambria", 1, 25)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jLabel3.setText("New Password");

        new_password.setFont(new java.awt.Font("Cambria", 1, 25)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jLabel4.setText("Confirm Password");

        conf_password.setFont(new java.awt.Font("Cambria", 1, 25)); // NOI18N

        chenge_pass_btn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        chenge_pass_btn.setText("Change Password");
        chenge_pass_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chenge_pass_btnActionPerformed(evt);
            }
        });

        chenge_pass_btn1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        chenge_pass_btn1.setText("Cancel");
        chenge_pass_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chenge_pass_btn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(conf_password, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(new_password, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(old_password, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(username_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(chenge_pass_btn)
                        .addGap(28, 28, 28)
                        .addComponent(chenge_pass_btn1)))
                .addContainerGap(122, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(old_password, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(new_password, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(conf_password, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chenge_pass_btn)
                    .addComponent(chenge_pass_btn1))
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void chenge_pass_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chenge_pass_btnActionPerformed
        if(username_txt.getText().equals("admin")){
            if(old_password.getText().equals("admin")){
                if(old_password.getText().equals(new_password.getText()))
                    JOptionPane.showMessageDialog(rootPane, "Old and New password shold not be same!");
                else{
                    if(new_password.getText().equals(conf_password.getText()) || !(new_password.getText().equals(""))){
                        JOptionPane.showConfirmDialog(rootPane, "Password Change Successfully");
                        LoginFrame lf = new LoginFrame();
                        lf.pass1 = new_password.getText();
                    }
                    else
                        JOptionPane.showMessageDialog(rootPane, "New password and Confirmed password should be the same!");
                }
            }
            else
                JOptionPane.showMessageDialog(rootPane,"Please enter correct Old Password!");
        }
        else if(username_txt.getText().equals("student")){
            if(old_password.getText().equals("student")){
                if(old_password.getText().equals(new_password.getText()))
                    JOptionPane.showMessageDialog(rootPane, "Old and New password shold not be same!");
                else{
                    if(new_password.getText().equals(conf_password.getText()) || !(new_password.getText().equals(""))){
                        JOptionPane.showConfirmDialog(rootPane, "Password Change Successfully");
                        LoginFrame lf = new LoginFrame();
                        lf.pass2 = new_password.getText();
                    }
                    else
                        JOptionPane.showMessageDialog(rootPane, "New password and Confirmed password should be the same!");
                }
            }
            else
                JOptionPane.showMessageDialog(rootPane,"Please enter correct Old Password!");
            
        }
    }//GEN-LAST:event_chenge_pass_btnActionPerformed

    private void chenge_pass_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chenge_pass_btn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chenge_pass_btn1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton chenge_pass_btn;
    private javax.swing.JButton chenge_pass_btn1;
    private javax.swing.JPasswordField conf_password;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField new_password;
    private javax.swing.JPasswordField old_password;
    private javax.swing.JTextField username_txt;
    // End of variables declaration//GEN-END:variables
}
