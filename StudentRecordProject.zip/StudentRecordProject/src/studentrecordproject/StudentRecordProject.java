
package studentrecordproject;

public class StudentRecordProject {
    public static void main(String[] args) {
        new LoginFrame().show();
    }
}
